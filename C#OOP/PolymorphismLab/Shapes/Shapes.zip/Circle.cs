﻿using System.Text;

namespace Shapes
{
    public class Circle : Shape
    {
        private int radius;

        public Circle(int radius)
        {
            this.radius = radius;
        }

        //public int Radius { get; private set; }
        public override double CalculateArea()
        {
            return 3.14*radius*radius;
        }

        public override double CalculatePerimeter()
        {
            return 2 * 3.14 * radius;
        }

        public override string Draw()
        {
            StringBuilder result = new StringBuilder();
            double rIn = this.radius - 0.4;
            double rOut = this.radius + 0.4;
            for (double y = this.radius; y >= -this.radius; --y)
            {
                for (double x = -this.radius; x < rOut; x += 0.5)
                {
                    double value = x * x + y * y;
                    if (value >= rIn * rIn && value <= rOut * rOut)
                        result.Append("*");
                    else
                        result.Append(" ");
                }
                result.AppendLine();
            }
            return result.ToString();
        }

    }
}
