﻿namespace SecondWildFarm.IO.Readers
{
    public interface IReader
    {
        public string ReadLine();
    }
}
