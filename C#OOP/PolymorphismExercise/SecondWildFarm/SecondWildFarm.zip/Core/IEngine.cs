﻿namespace SecondWildFarm.Core
{
    public interface IEngine
    {
        public void Run();
    }
}
