﻿using System;

namespace Vehicles
{
    public class StartUp
    {
        public static void Main()
        {
            string[] carInfo = Console.ReadLine().Split();
            Car car = new Car(double.Parse(carInfo[1]), double.Parse(carInfo[2]));

            string[] truckInfo = Console.ReadLine().Split();
            Truck truck = new Truck(double.Parse(truckInfo[1]), double.Parse(truckInfo[2]));

            int commandCounts = int.Parse(Console.ReadLine());

            for (int i = 0; i < commandCounts; i++)
            {
                string[] commandTokens = Console.ReadLine().Split();
                string command = commandTokens[0];
                string vehicleType = commandTokens[1];
                double amount = double.Parse(commandTokens[2]);

                if (command == "Drive")
                {
                    if (vehicleType == "Car")
                    {
                        Console.WriteLine(car.Drive(amount));
                    }
                    else if (vehicleType == "Truck")
                    {
                        Console.WriteLine(truck.Drive(amount));
                    }
                }
                else if (command == "Refuel")
                {
                    if (vehicleType == "Car")
                    {
                        car.Refuel(amount);
                    }
                    else if (vehicleType == "Truck")
                    {
                        truck.Refuel(amount);
                    }
                }
            }

            Console.WriteLine($"Car: {Math.Round(car.FuelQuantity,2):F2}");
            Console.WriteLine($"Truck: {Math.Round(truck.FuelQuantity,2):F2}");
        }
    }
}
