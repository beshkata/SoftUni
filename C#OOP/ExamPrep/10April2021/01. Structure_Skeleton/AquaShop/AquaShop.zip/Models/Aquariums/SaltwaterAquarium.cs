﻿

namespace AquaShop.Models.Aquariums
{
    public class SaltwaterAquarium : Aquarium
    {
        public SaltwaterAquarium(string name)
            : base(name, 25)
        {
            
        }
    }
}
