﻿namespace Telephony.Contracts
{
    public interface IBrowseable
    {
        public string Browse(string urlAddress);
    }
}
