﻿namespace MilitaryElite.Contracts
{
    public interface ISpecialisedSoldier
    {
        public string Corps { get; }
    }
}
