﻿using MilitaryElite.Enums;

namespace MilitaryElite.Contracts
{
    public interface ISpecialisedSoldier
    {
        public Corps Corps { get; }
    }
}
