﻿namespace MilitaryElite.Contracts
{
    public interface ISpy
    {
        public int CodeNumber { get; }
    }
}
