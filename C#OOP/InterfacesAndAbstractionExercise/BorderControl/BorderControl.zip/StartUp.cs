﻿using BorderControl.Contracts;
using BorderControl.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
    class StartUp
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> identifiables = new List<IIdentifiable>();

            while (true)
            {
                string input = Console.ReadLine();
                if (input == "End")
                {
                    break;
                }

                string[] tokens = input.Split();

                if (tokens.Length == 2)
                {
                    string model = tokens[0];
                    string id = tokens[1];
                    IIdentifiable robot = new Robot(model, id);
                    identifiables.Add(robot);
                }
                else
                {
                    string name = tokens[0];
                    int age = int.Parse(tokens[1]);
                    string id = tokens[2];
                    IIdentifiable citizen = new Citizen(name, age, id);
                    identifiables.Add(citizen);
                }
            }

            string fakeId = Console.ReadLine();

            foreach (IIdentifiable identifiable in identifiables)
            {
                if(identifiable.Id.EndsWith(fakeId))
                {
                    Console.WriteLine(identifiable.Id);
                }
            }
        }
    }
}
