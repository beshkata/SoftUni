﻿namespace P03_FootballBetting.Data.Models.Enums
{
    public enum Prediction
    {
        Home = 1,
        Away = 2,
        Draw = 0
    }
}
