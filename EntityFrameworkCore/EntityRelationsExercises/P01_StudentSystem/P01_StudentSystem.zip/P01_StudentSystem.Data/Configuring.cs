﻿namespace P01_StudentSystem.Data
{
    public static class Configuring
    {
        public const string CONNECTION_STRING = @"Server=RAPTOR\SQLEXPRESS;Database=StudentSystem;Integrated Security=true;";
    }
}
