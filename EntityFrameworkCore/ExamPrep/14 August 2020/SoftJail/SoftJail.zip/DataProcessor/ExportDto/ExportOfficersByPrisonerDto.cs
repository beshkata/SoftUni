﻿namespace SoftJail.DataProcessor.ExportDto
{
    public class ExportOfficersByPrisonerDto
    {
        public string OfficerName { get; set; }

        public string Department { get; set; }
    }
}
