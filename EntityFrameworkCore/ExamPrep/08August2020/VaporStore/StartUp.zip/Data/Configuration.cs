﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=.;Database=VaporStore;Trusted_Connection=True";
		//public static string ConnectionString = @"Server=RAPTOR\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";

	}
}