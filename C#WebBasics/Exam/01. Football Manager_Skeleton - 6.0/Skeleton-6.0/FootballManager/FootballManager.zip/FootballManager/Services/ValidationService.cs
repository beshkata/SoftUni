﻿using FootballManager.Contracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballManager.Services
{
    public class ValidationService : IValidationService
    {
        public bool ValidateModel(object model)
        {
            var context = new ValidationContext(model);
            var errorResult = new List<ValidationResult>();

            return Validator.TryValidateObject(model, context, errorResult, true);
        }
    }
}
