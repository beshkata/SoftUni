﻿namespace FootballManager.Contracts
{
    public interface IValidationService
    {
        bool ValidateModel(object model);
    }
}
